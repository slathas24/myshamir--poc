
//defining the Connection details 
export type Connection = {
        user: string,
        password: string,
        host: string,
        port: number, // PostgreSQL default port
        database: string
};

export const pgconn1: Connection= { user: "postgres", password: "postgres", host:  'localhost',port: 5435, database: "postgres"}  // PostgreSQL default port}
export const pgconn2: Connection= { user: "postgres", password: "postgres", host:  'localhost',port: 5433, database: "postgres"}  // PostgreSQL default port}
export const mysqlcon: Connection = {
  host: '127.0.0.1',  //'DESKTOP-AI9J04E',
  user: 'mysql',
  password: 'mysql',
  database: 'mysql',
  port: 3306

}
export class SecretRecord {
       public userid: string
      public  appid:string
      public  keyvalue:string
      public  secretvalue:string
      public  constructor(uid:string,apid:string,kv:string,sv:string) {
        this.userid = uid
        this.appid=apid
        this.keyvalue=kv
        this.secretvalue=sv
      }

}
export * as dto from './dto'
