"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SECRET_PATH = exports.VAULT_TOKEN = exports.VAULT_URL = void 0;
exports.VAULT_URL = "http://localhost:8200";
exports.VAULT_TOKEN = "hvs.fxVw5jhTHx8Ze1FMLqrmFuuH";
exports.SECRET_PATH = "secret/data/";
