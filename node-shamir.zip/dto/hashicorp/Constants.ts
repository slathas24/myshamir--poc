export const VAULT_URL = "http://localhost:8200"
export const VAULT_TOKEN = "hvs.fxVw5jhTHx8Ze1FMLqrmFuuH"
export const SECRET_PATH = "secret/data/"

