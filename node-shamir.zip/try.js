"use strict";
/*const str:string = './try2'
const fn:string = 'hello'

//const s = require(str)
//console.log(s.myc("hello","wo"))
const arr=["./try2","./try2"]
const st=["myc('hello','lll')","myc2('world')"]
for (var i=0;i<2;i++) {
    var x=st[i]
    console.log(x)
   import(arr[i])
   .then( m => console.log(m.))
   .catch (() => console.log("error"))
}
*/ 
