"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.myc2 = exports.myc = void 0;
function myc(a, b) {
    return a + " " + b;
}
exports.myc = myc;
function myc2(a) {
    return "func 2" + a;
}
exports.myc2 = myc2;
