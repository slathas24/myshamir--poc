export function myc(a:string,b:string) {
    return a+" "+b
}

export function myc2(a:string) {
    return "func 2"+a
}